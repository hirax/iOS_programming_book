# https://gist.github.com/jsbain/2cf4998949f49b58ff284239784e1561

from objc_util import *
import ctypes
import numpy as np
import io
import time

AVFoundation = ctypes.cdll.LoadLibrary(
  "/System/Library/Frameworks/AVFoundation.framework/AVFoundation"
)
AudioToolbox = ctypes.cdll.LoadLibrary(
  "/System/Library/Frameworks/AudioToolbox.framework/AudioToolbox"
)

# AVAudio Define
AVAudioEngine=ObjCClass('AVAudioEngine')
AVAudioSession=ObjCClass('AVAudioSession')
AVAudioPlayerNode=ObjCClass('AVAudioPlayerNode')
AVAudioFile=ObjCClass('AVAudioFile')
AVAudioUnitEQ=ObjCClass('AVAudioUnitEQ')
AVAudioMixerNode=ObjCClass('AVAudioMixerNode')
AVAudioPCMBuffer=ObjCClass('AVAudioPCMBuffer')
AVAudioFormat=ObjCClass('AVAudioFormat')
AVAudioUnitEQFilterParameters=ObjCClass('AVAudioUnitEQFilterParameters')
AVAudioSessionPortDescription=ObjCClass('AVAudioSessionPortDescription')
AVAudioCompressedBuffer=ObjCClass('AVAudioCompressedBuffer')
AVAudioConverter=ObjCClass('AVAudioConverter')
AVAudioTime=ObjCClass('AVAudioTime')

class AudioStreamBasicDescription(ctypes.Structure):
    _fields_=[('mSampleRate',ctypes.c_double),('mFormatID',ctypes.c_uint32),('mFormatFlags',ctypes.c_uint32),('mBytesPerPacket',ctypes.c_uint32),('mFramesPerPacket',ctypes.c_uint32),('mBytesPerFrame',ctypes.c_uint32),('mChannelsPerFrame',ctypes.c_uint32),('mBitsPerChannel',ctypes.c_uint32),('mReserved',ctypes.c_uint32)]

def setup():
    error = ctypes.c_void_p(0)
    session = AVAudioSession.sharedInstance()
    category = session.setCategory(
        'AVAudioSessionCategoryPlayAndRecord',
        error = ctypes.pointer( error ))
    print( session.category() )
    #category = session.setCategory_('AVAudioSessionCategoryPlayAndRecord')
    if error:
        raise Exception('error setting up category')
    session.setActive( True, error=ctypes.pointer(error) )
    if error:
        raise Exception( 'error setting up session active' )
    engine = AVAudioEngine.new()
    return engine

def f(audio_array):
    print(len(audio_array))

audio_input_process_func = f
#audio_input_engine = None
AVAudioEngine_ = None
audio_in_buf = []
image_convert_bIO = io.BytesIO()
lastt = 0

# オーディオを処理する
def processBuffer( self, buffer, when, cmd):
    print("called.")
    try:
        global audio_in_buf, lastt
        #global audio_input_process_func
        
        #audio_in_buf = ObjCInstance( buffer ) # ここ
        
	    #t = ObjCInstance(when).sampleTime() / 44100.
	    #fps=1./(t-lastt)
	    #lastt=t
        
        #A = np.ctypeslib.as_array(            # ここ
        #    audio_in_buf.floatChannelData()[0],
        #    (128, 128) )
        
        #print(A[0])
        #print("called.")
        #audio_input_process_func(A)
        
        #B = np.transpose(
        #        np.log10( np.fft.fftshift(
        #            abs( np.fft.fft(A, 512) )
        #            )
        #    ))
        #matplotlib.image.imsave(image_convert_bIO,B,format='png',vmin=-3,vmax=1)
        #v.update(ui.Image.from_data(image_convert_bIO.getvalue()))
        #image_convert_bIO.seek( 0 )
        pass
    except:
        raise

# 定義関数からオーディオを処理するBlockを作る
# self, func, restype, argtypes
process_block = ObjCBlock(
    processBuffer,
    restype = None,
    argtypes = [ c_void_p, c_void_p, c_void_p, c_void_p ] )
retain_global(process_block)

def setup_audio_input_engine():
    global AVAudioEngine_
    global process_block
    # AudioEngine を作成
    AVAudioEngine_ = setup()
    # Connect devices
    #AVAudioEngine_.connect_to_format_(
    #    audio_input_engine.inputNode(),
    #    audio_input_engine.outputNode(),
    #    audio_input_engine.inputNode().inputFormatForBus_(0) )
    # Mixer
    mixer = AVAudioEngine_.mainMixerNode()
    input = AVAudioEngine_.inputNode()
    #AVAudioEngine_.connect_to_format_(
    #    input, mixer, input.inputFormatForBus_(0) )
    print( input.inputFormatForBus(0).channelCount() )
    # オーディオを処理するBlockを登録する
    try:
        #input.installTapOnBus(
        #    0, bufferSize = 16*16*256,  # 16*256= 4096
        #    format = None, block = process_block )
        input.removeTapOnBus_(0)
        input.installTapOnBus_bufferSize_format_block_(
            0, 90192,#64*256=4096
            input.outputFormatForBus_(0), process_block )
        #AVAudioFormat.alloc().initWithCommonFormat_sampleRate_channels_interleaved_(1,44100,1,False),
    except:
        print('can not install')
        raise
    print("setup is done.")

def start_audio_input_engine():
    global AVAudioEngine_
    global process_block
    print(process_block)
    #time.sleep(5)
    AVAudioEngine_.prepare()
    AVAudioEngine_.startAndReturnError_(None)

def stop_audio_input_engine():
    global AVAudioEngine_
    AVAudioEngine_.stop()
    AVAudioEngine_.reset()
