from objc_util import ObjCClass

NSPredicate = ObjCClass('NSPredicate')
NSSortDescriptor = ObjCClass('NSSortDescriptor')
