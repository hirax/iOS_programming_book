import avfaudio.audio_capturing as ac
from uikit.ui_uiview_for_pythonista import *
import time
from objc_util import *

print("start")
time.sleep(3)
#print(UIScreen.mainScreen().bounds().size)
#@on_main_thread
size = get_screen_bounds()
main_view = get_mainview()

print(main_view)
ui_view = create_uiview(
        #rect=CGRect( CGPoint(size.width/4/2, size.height/4/2),
        #               CGSize(3*size.width/4, 3*size.height/4)),
        rect=CGRect( CGPoint(0, 0),
                       CGSize(500, 500)),
        name='sample',
        color=UIColor.color(red=0,green=0,blue=0,alpha=1) )
add_uiview_to_mainview(ui_view, main_view)
print("window")

time.sleep(1)
ac.setup_audio_input_engine()
time.sleep(0.1)

ac.start_audio_input_engine()
time.sleep(5)
ac.stop_audio_input_engine()

remove_uiview_fromsuper(ui_view)
print('m')
