from objc_util import *

UIView = ObjCClass('UIView')
UIScreen = ObjCClass('UIScreen')

# ObjCInstance(ここ).addSubview_(self._scene_objc)
@on_main_thread
def create_uiview(
        frame = (0, 0, 100, 100),
        flex='',
        backgroundColor = UIColor.color(red=1,green=1,blue=1,alpha=1.0),
        name = 'sample'
    ):
    rect = CGRect( CGPoint( frame[0], frame[1]),
                   CGSize(  frame[2], frame[3]) )
    ui_view = UIView.alloc().initWithFrame_(rect)
    ui_view.name = name
    ui_view.backgroundColor = backgroundColor
    return ui_view

class View():

    def __init__(self,*args):
        self = create_uiview()
        return self
        
    def present(self, style='default', animated=True, popover_location=None, hide_title_bar=False, title_bar_color=None, title_color=None, orientations=None, hide_close_button=False):
        print(self.backgroundColor)
        pass
    

@on_main_thread
def get_screen_size():
    import dataclasses

    @dataclasses.dataclass
    class Screen:
        width: int
        height: int
    
    size = UIScreen.mainScreen().bounds().size
    return Screen(width=size.width, height=size.height)

