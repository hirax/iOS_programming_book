from objc_util import *
import ctypes
from uikit.ui_uiview import *
import numpy as np
import copy

NSDictionary = ObjCClass('NSDictionary')

AVCaptureSession = ObjCClass('AVCaptureSession')
AVCaptureDevice = ObjCClass('AVCaptureDevice')
AVCaptureDeviceInput = ObjCClass('AVCaptureDeviceInput')
AVCaptureVideoDataOutput = ObjCClass('AVCaptureVideoDataOutput')
AVCaptureVideoPreviewLayer = ObjCClass('AVCaptureVideoPreviewLayer')
AVCaptureConnection = ObjCClass('AVCaptureConnection')
AVCaptureDeviceDiscoverySession = ObjCClass('AVCaptureDeviceDiscoverySession')

# dispatch_get_current_queue 関数のポインタ指定、引数型はvoid・返値型定義
dispatch_get_current_queue = c.dispatch_get_current_queue
dispatch_get_current_queue.restype = c_void_p
# CMSampleBufferGetImageBuffer 関数のポインタ指定、引数型・返値型定義
CMSampleBufferGetImageBuffer = c.CMSampleBufferGetImageBuffer
CMSampleBufferGetImageBuffer.argtypes = [c_void_p]
CMSampleBufferGetImageBuffer.restype = c_void_p
# CVPixelBufferLockBaseAddress 関数のポインタ指定、引数型・返値型定義
CVPixelBufferLockBaseAddress = c.CVPixelBufferLockBaseAddress
CVPixelBufferLockBaseAddress.argtypes = [c_void_p, c_int]
CVPixelBufferLockBaseAddress.restype = None
# CVPixelBufferUnlockBaseAddress 関数のポインタ指定、引数型・返値型定義
CVPixelBufferUnlockBaseAddress = c.CVPixelBufferUnlockBaseAddress
CVPixelBufferUnlockBaseAddress.argtypes = [c_void_p, c_int]
CVPixelBufferUnlockBaseAddress.restype = None

# PixelBuffer Definitions
CVPixelBufferGetWidthOfPlane = c.CVPixelBufferGetWidthOfPlane
CVPixelBufferGetWidthOfPlane.argtypes = [ctypes.c_void_p, ctypes.c_int]
CVPixelBufferGetWidthOfPlane.restype = ctypes.c_int

CVPixelBufferGetHeightOfPlane = c.CVPixelBufferGetHeightOfPlane
CVPixelBufferGetHeightOfPlane.argtypes = [ctypes.c_void_p, ctypes.c_int]
CVPixelBufferGetHeightOfPlane.restype = ctypes.c_int

CVPixelBufferGetBaseAddressOfPlane = c.CVPixelBufferGetBaseAddressOfPlane
CVPixelBufferGetBaseAddressOfPlane.argtypes = [ctypes.c_void_p, ctypes.c_int]
CVPixelBufferGetBaseAddressOfPlane.restype = ctypes.c_void_p

CVPixelBufferGetBytesPerRowOfPlane = c.CVPixelBufferGetBytesPerRowOfPlane
CVPixelBufferGetBytesPerRowOfPlane.argtypes = [ctypes.c_void_p, ctypes.c_int]
CVPixelBufferGetBytesPerRowOfPlane.restype = ctypes.c_int

CIImage = ObjCClass('CIImage')

AVCaptureDeviceTypeExternalUnknown = 'AVCaptureDeviceTypeExternalUnknown'
AVCaptureDeviceTypeBuiltInMicrophone = 'AVCaptureDeviceTypeBuiltInMicrophone'
AVCaptureDeviceTypeBuiltInWideAngleCamera = 'AVCaptureDeviceTypeBuiltInWideAngleCamera'
AVCaptureDeviceTypeBuiltInTelephotoCamera = 'AVCaptureDeviceTypeBuiltInTelephotoCamera'
AVCaptureDeviceTypeBuiltInUltraWideCamera = 'AVCaptureDeviceTypeBuiltInUltraWideCamera'
AVCaptureDeviceTypeBuiltInDualCamera = 'AVCaptureDeviceTypeBuiltInDualCamera'
AVCaptureDeviceTypeBuiltInDualWideCamera = 'AVCaptureDeviceTypeBuiltInDualWideCamera'
AVCaptureDeviceTypeBuiltInTripleCamera = 'AVCaptureDeviceTypeBuiltInTripleCamera'
AVCaptureDeviceTypeBuiltInTrueDepthCamera = 'AVCaptureDeviceTypeBuiltInTrueDepthCamera'
AVCaptureDeviceTypeBuiltInDuoCamera = 'AVCaptureDeviceTypeBuiltInDuoCamera'
AVCaptureDeviceTypeBuiltInLiDARDepthCamera = 'AVCaptureDeviceTypeBuiltInLiDARDepthCamera'

# https://docs.microsoft.com/ja-jp/dotnet/api/avfoundation.avcapturedevicetype?view=xamarin-ios-sdk-12
BuiltInMicrophone  =  0
BuiltInTelephotoCamera  =  2
#BuiltInDuoCamera  =  3
BuiltInDualCamera  =  4
BuiltInTrueDepthCamera  =  5

# AVCaptureDevicePosition
AVCaptureDevicePositionBack = 1  # AVCaptureDevicePositionUnspecified = 0?
AVCaptureDevicePositionFront = 2

# 下記多分間違ってる
AVMediaTypeVideo = 0
AVMediaTypeAudio = 1
AVMediaTypeText = 2
AVMediaTypeClosedCaption = 3
AVMediaTypeSubtitle = 4
AVMediaTypeTimecode = 5
AVMediaTypeMetadata = 6
AVMediaTypeMuxed = 7

main_view = None
session = None
delegate = None
output = None
processed_frames = 0
images = []

def processPixelBuffer(pixelData):
    global images
    base_address  = CVPixelBufferGetBaseAddressOfPlane(pixelData, 0)
    bytes_per_row = CVPixelBufferGetBytesPerRowOfPlane(pixelData, 0)
    width = CVPixelBufferGetWidthOfPlane(pixelData, 0)
    height = CVPixelBufferGetHeightOfPlane(pixelData, 0)
    image = np.ctypeslib.as_array(
        ctypes.cast( base_address, ctypes.POINTER(ctypes.c_ubyte) ),
        shape=((height+int(height/2), width))  ) # YUV_420_888
    images.append(copy.copy(image))

def captureOutput_didOutputSampleBuffer_fromConnection_(
              _self, _cmd, _output, _sample_buffer, _conn):
    global processed_frames
    # サンプルバッファを読み込む
    _imageBuffer = CMSampleBufferGetImageBuffer(_sample_buffer)
    # サンプルバッファをロック
    CVPixelBufferLockBaseAddress(_imageBuffer, 0)
    # サンプルバッファを使った処理
    processPixelBuffer(_imageBuffer)
    # サンプルバッファをアンロック
    CVPixelBufferUnlockBaseAddress(_imageBuffer, 0)
    processed_frames = processed_frames + 1

# delegate を登録する
sampleBufferDelegate = create_objc_class(
        'sampleBufferDelegate',
        methods=[captureOutput_didOutputSampleBuffer_fromConnection_],
        protocols=['AVCaptureVideoDataOutputSampleBufferDelegate'])

def button_tapped(sender):
    global debugflg
    debugflg = 1
    
@on_main_thread
def video_shooting_setup(ui_view, captureDeviceType, sessionPreset = 'AVCaptureSessionPreset640x480'):
    global session, delegate, output
    # ui_viewを追加
    main_view = get_view_controllers()[1].view()
    add_uiview_to_mainview(ui_view,main_view)
    
    # デバイスを開く
    # https://forum.omz-software.com/user/pavlinb/posts
    captureDeviceDiscoverySession = AVCaptureDeviceDiscoverySession.discoverySessionWithDeviceTypes_mediaType_position_(
        [ captureDeviceType ], # AVCaptureDeviceTypeBuiltInWideAngleCamera
        'vide', # AVMediaTypeVideo
        1 ) # AVCaptureDevicePositionBack
    captureDevices = captureDeviceDiscoverySession.devices()
    device = captureDevices[0] # 該当する最初のデバイスを選択
    print(device)
    # キャプチャデバイスから”input”を作る
    _input = AVCaptureDeviceInput.deviceInputWithDevice_error_(device, None)
    if _input:
        # AVCaptureSession
        session = AVCaptureSession.alloc().init()
        session.addInput_(_input)
    else:
        return
    # 画像をキャプチャするdelegateを作成
    delegate = sampleBufferDelegate.new()
    queue = ObjCInstance( dispatch_get_current_queue() )
    # AVCaptureVideoDataOutput を作成
    output = AVCaptureVideoDataOutput.alloc().init()
    print( output.availableVideoCVPixelFormatTypes() ) # avialableVideoPixelFormatTypes は使えない？
    output.setVideoSettings_(
        NSDictionary.dictionaryWithObject_forKey_(
         ns(875704422),
         ns('kCVPixelBufferPixelFormatTypeKey'))) # CV420YpCbCr8BiPlanarFullRange
    output.videoSettings = {ns('kCVPixelBufferPixelFormatTypeKey'): ns(875704438)}
    print(output.videoSettings())
    output.alwaysDiscardsLateVideoFrames = True
    # 画像をキャプチャするdelegateとqueue設定
    output.setSampleBufferDelegate_queue_( delegate, queue )
    # session に output を接続
    session.addOutput_(output)
    session.sessionPreset = sessionPreset
    # キャプチャデバイスからのビデオを表示するためのAVCaptureVideoPreviewLayer
    prev_layer = AVCaptureVideoPreviewLayer.layerWithSession_(session)
    prev_layer.setVideoGravity_('AVLayerVideoGravityResizeAspectFill')
    prev_layer.frame = ui_view.bounds()
    print(ui_view)
    print(ui_view.layer())
    ui_view.layer().addSublayer_(prev_layer)

@on_main_thread
def video_shooting_start():
    global session
    session.startRunning()

@on_main_thread
def video_shooting_close(ui_view):
    global session, delegate, output, processed_frames
    session.stopRunning()
    delegate.release()
    session.release()
    output.release()
    # プレビューレイヤーを消す（Noneにはしない）
    remove_uiview_fromsuper(ui_view)
    print( "processed_frames:{}".format(processed_frames))

if __name__ == '__main__':
    main()



