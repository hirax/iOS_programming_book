
from objc_util import *
from ctypes import c_void_p, cast
import time

CIImage = ObjCClass('CIImage') # ここ？
UIImage = ObjCClass('UIImage')# ここ？

AVCaptureSession = ObjCClass('AVCaptureSession')
AVCaptureDevice = ObjCClass('AVCaptureDevice')
AVCaptureDeviceInput = ObjCClass('AVCaptureDeviceInput')
AVCaptureVideoDataOutput = ObjCClass('AVCaptureVideoDataOutput')
AVCaptureVideoPreviewLayer = ObjCClass('AVCaptureVideoPreviewLayer')

dispatch_get_current_queue = c.dispatch_get_current_queue
dispatch_get_current_queue.restype = c_void_p

CMSampleBufferGetImageBuffer = c.CMSampleBufferGetImageBuffer
CMSampleBufferGetImageBuffer.argtypes = [c_void_p]
CMSampleBufferGetImageBuffer.restype = c_void_p

CVPixelBufferLockBaseAddress = c.CVPixelBufferLockBaseAddress
CVPixelBufferLockBaseAddress.argtypes = [c_void_p, c_int]
CVPixelBufferLockBaseAddress.restype = None

CVPixelBufferUnlockBaseAddress = c.CVPixelBufferUnlockBaseAddress
CVPixelBufferUnlockBaseAddress.argtypes = [c_void_p, c_int]
CVPixelBufferUnlockBaseAddress.restype = None

ciContext = ObjCClass('CIContext')
ctx = ciContext.contextWithOptions_(None)

def write_output(out_ci_img, filename='.output.jpg'):
    ctx = ciContext.contextWithOptions_(None)
    cg_img = ctx.createCGImage_fromRect_(out_ci_img, out_ci_img.extent())
    ui_img = UIImage.imageWithCGImage_(cg_img)
    c.CGImageRelease.argtypes = [c_void_p]
    c.CGImageRelease.restype = None
    c.CGImageRelease(cg_img)
    c.UIImageJPEGRepresentation.argtypes = [c_void_p, CGFloat]
    c.UIImageJPEGRepresentation.restype = c_void_p
    data = ObjCInstance(c.UIImageJPEGRepresentation(ui_img.ptr, 0.75))
    data.writeToFile_atomically_(filename, True)

    return filename

# delegateの作成
def captureOutput_didOutputSampleBuffer_fromConnection_(_self, _cmd, _output, _sample_buffer, _connection):
    _image_buffer = CMSampleBufferGetImageBuffer(_sample_buffer)
    CVPixelBufferLockBaseAddress(_image_buffer, 0)
    # CIImage作成
    ciimage = CIImage.imageWithCVPixelBuffer_(ObjCInstance(_image_buffer))
    CVPixelBufferUnlockBaseAddress(_image_buffer, 0)

SampleBufferDelegate = create_objc_class(
                'SampleBufferDelegate',
                methods=[captureOutput_didOutputSampleBuffer_fromConnection_],
                protocols=['AVCaptureVideoDataOutputSampleBufferDelegate'])

@on_main_thread
def main():
    global session, delegate, output

    SampleBufferDelegate_ = SampleBufferDelegate.new()

    frame_w = 375; frame_h = 550

    session = AVCaptureSession.alloc().init()
    # ここのデバイス選択は入れ替える
    device = AVCaptureDevice.defaultDeviceWithMediaType_('vide')

    _input = AVCaptureDeviceInput.deviceInputWithDevice_error_(device, None)

    if _input:
        session.addInput_(_input)
        print('succesed!')
    else:
        print('Failed to create input')
        return

    output = AVCaptureVideoDataOutput.alloc().init()
    queue = ObjCInstance( dispatch_get_current_queue() )
    output.setSampleBufferDelegate_queue_(SampleBufferDelegate_, queue)
    output.alwaysDiscardsLateVideoFrames = True

    session.addOutput_(output)

    session.sessionPreset = 'AVCaptureSessionPreset640x480'

    session.startRunning()
    session.stopRunning()
    delegate.release()
    session.release()
    output.release()

if __name__ == '__main__':
    main()
