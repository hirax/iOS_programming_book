# coding: utf-8
# Copyright (c) 2018 Jun Hirabayashi (jun@hirax.net)
# Released under the MIT license
# https://opensource.org/licenses/mit-license.php

from classes.header import *

# クラスのインスタンスを作成
CMMotionManager_ = CMMotionManager.alloc().init()
if not CMMotionManager_.isDeviceMotionAvailable():
    print("DeviceMotion in NOT Available.")
    raise
else:
    print("DeviceMotion is Available.")

# 便利のために変数などを用意しておく
CMMotionManager_.deviceMotionUpdateInterval = 0.1 # 単位は秒
deviceMotionUpdateInterval = CMMotionManager_.deviceMotionUpdateInterval
    
def deviceMotion():
        data = CMMotionManager_.deviceMotion
        # （Classでなく）structのpropertyに対してはメッセージを投げる
        deviceMotionData = {
            'attitude':data.attitude,
            'rotationRate':member(data, "rotationRate", CMRotationRate),
            'gravity':member(data, "gravity", CMAcceleration),
            'userAcceleration':member(data, "userAcceleration", CMAcceleration),
            'magneticField':member(data, "magneticField", CMMagneticField),
            'heading':data.heading,
            'sensorLocation':data.sensorLocation
        }
        return deviceMotionData

def startDeviceMotionUpdates():
        CMMotionManager_.startDeviceMotionUpdates()
        CMMotionManager_.showsDeviceMovementDisplay = True

def stopDeviceMotionUpdates():
        CMMotionManager_.stopDeviceMotionUpdates()

if __name__ == '__main__':
    import time
    # 加速度センサ値を格納する変数を初期化しておく
    accelerometerData.clear()
    # 計測を開始する
    CMMotionManager_.startDeviceMotionUpdates()
    # * 秒間計測を続ける
    time.sleep(3) # 単位は秒
    # 結果を表示
    print( deviceMotion() )
    # 計測を終了させる
    CMMotionManager_.stopDeviceMotionUpdates()
    
