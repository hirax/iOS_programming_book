# coding: utf-8
# Copyright (c) 2018 Jun Hirabayashi (jun@hirax.net)
# Released under the MIT license
# https://opensource.org/licenses/mit-license.php

from ctypes import *

AudioToolbox = cdll.LoadLibrary(
  "/System/Library/Frameworks/AudioToolbox.framework/AudioToolbox"
)

def audio_services_play_system_sound(SIMToolkitGeneralBeep = 1052)
    AudioToolbox.AudioServicesPlaySystemSound( SIMToolkitGeneralBeep )

