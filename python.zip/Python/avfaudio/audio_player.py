from rubicon.objc import ObjCClass
from os.path import abspath
from ctypes import cdll, c_int, byref
from avfaudio.sound import *
import os
import time

AudioToolbox = cdll.LoadLibrary(
  "/System/Library/Frameworks/AudioToolbox.framework/AudioToolbox")
AVFoundation = cdll.LoadLibrary(
        "/System/Library/Frameworks/AVFoundation.framework/AVFoundation")
NSURL = ObjCClass("NSURL")

AVAudioPlayer = ObjCClass("AVAudioPlayer")

def audioPlayer_fromUrl(url):
    return  AVAudioPlayer.alloc().initWithContentsOfURL(
       url, error = None)
