from objc_util import *
import ctypes
from uikit.ui_uiview import *
import numpy as np
import copy
from uikit.ui_uiview import *

AVFoundation = ctypes.cdll.LoadLibrary(
  "/System/Library/Frameworks/AVFoundation.framework/AVFoundation"
)

NSDictionary = ObjCClass('NSDictionary')

AVCaptureSession = ObjCClass('AVCaptureSession')
AVCaptureDevice = ObjCClass('AVCaptureDevice')
AVCaptureDeviceInput = ObjCClass('AVCaptureDeviceInput')

AVCaptureVideoDataOutput = ObjCClass('AVCaptureVideoDataOutput')
AVCaptureDepthDataOutput = ObjCClass('AVCaptureDepthDataOutput')

AVCaptureDataOutputSynchronizer = ObjCClass('AVCaptureDataOutputSynchronizer')
AVCaptureSynchronizedDepthData = ObjCClass('AVCaptureSynchronizedDepthData')
AVCaptureSynchronizedSampleBufferData = ObjCClass('AVCaptureSynchronizedSampleBufferData')

AVCaptureVideoPreviewLayer = ObjCClass('AVCaptureVideoPreviewLayer')
AVCaptureConnection = ObjCClass('AVCaptureConnection')
AVCaptureDeviceDiscoverySession = ObjCClass('AVCaptureDeviceDiscoverySession')

AVCaptureSynchronizedDataCollection = ObjCClass('AVCaptureSynchronizedDataCollection')

# dispatch_get_current_queue 関数のポインタ指定、引数型はvoid・返値型定義
dispatch_get_current_queue = c.dispatch_get_current_queue
dispatch_get_current_queue.restype = c_void_p
# CMSampleBufferGetImageBuffer 関数のポインタ指定、引数型・返値型定義
CMSampleBufferGetImageBuffer = c.CMSampleBufferGetImageBuffer
CMSampleBufferGetImageBuffer.argtypes = [c_void_p]
CMSampleBufferGetImageBuffer.restype = c_void_p
# CVPixelBufferLockBaseAddress 関数のポインタ指定、引数型・返値型定義
CVPixelBufferLockBaseAddress = c.CVPixelBufferLockBaseAddress
CVPixelBufferLockBaseAddress.argtypes = [c_void_p, c_int]
CVPixelBufferLockBaseAddress.restype = None
# CVPixelBufferUnlockBaseAddress 関数のポインタ指定、引数型・返値型定義
CVPixelBufferUnlockBaseAddress = c.CVPixelBufferUnlockBaseAddress
CVPixelBufferUnlockBaseAddress.argtypes = [c_void_p, c_int]
CVPixelBufferUnlockBaseAddress.restype = None

#CVPixelBufferGetBaseAddress
CVPixelBufferGetBaseAddress = c.CVPixelBufferGetBaseAddress
CVPixelBufferGetBaseAddress.argtypes = [ctypes.c_void_p]
CVPixelBufferGetBaseAddress.restype = ctypes.c_int

CVPixelBufferGetWidth = c.CVPixelBufferGetWidth
CVPixelBufferGetWidth.argtypes = [ctypes.c_void_p]
CVPixelBufferGetWidth.restype = ctypes.c_int

CVPixelBufferGetHeight = c.CVPixelBufferGetHeight
CVPixelBufferGetHeight.argtypes = [ctypes.c_void_p]
CVPixelBufferGetHeight.restype = ctypes.c_int

CVPixelBufferGetBytesPerRow = c.CVPixelBufferGetBytesPerRow
CVPixelBufferGetBytesPerRow.argtypes = [ctypes.c_void_p]
CVPixelBufferGetBytesPerRow.restype = ctypes.c_int


# PixelBuffer Definitions
CVPixelBufferGetWidthOfPlane = c.CVPixelBufferGetWidthOfPlane
CVPixelBufferGetWidthOfPlane.argtypes = [ctypes.c_void_p, ctypes.c_int]
CVPixelBufferGetWidthOfPlane.restype = ctypes.c_int

CVPixelBufferGetHeightOfPlane = c.CVPixelBufferGetHeightOfPlane
CVPixelBufferGetHeightOfPlane.argtypes = [ctypes.c_void_p, ctypes.c_int]
CVPixelBufferGetHeightOfPlane.restype = ctypes.c_int

CVPixelBufferGetBaseAddressOfPlane = c.CVPixelBufferGetBaseAddressOfPlane
CVPixelBufferGetBaseAddressOfPlane.argtypes = [ctypes.c_void_p, ctypes.c_int]
CVPixelBufferGetBaseAddressOfPlane.restype = ctypes.c_void_p

CVPixelBufferGetBytesPerRowOfPlane = c.CVPixelBufferGetBytesPerRowOfPlane
CVPixelBufferGetBytesPerRowOfPlane.argtypes = [ctypes.c_void_p, ctypes.c_int]
CVPixelBufferGetBytesPerRowOfPlane.restype = ctypes.c_int

CIImage = ObjCClass('CIImage')

AVCaptureDeviceTypeExternalUnknown = 'AVCaptureDeviceTypeExternalUnknown'
AVCaptureDeviceTypeBuiltInMicrophone = 'AVCaptureDeviceTypeBuiltInMicrophone'
AVCaptureDeviceTypeBuiltInWideAngleCamera = 'AVCaptureDeviceTypeBuiltInWideAngleCamera'
AVCaptureDeviceTypeBuiltInTelephotoCamera = 'AVCaptureDeviceTypeBuiltInTelephotoCamera'
AVCaptureDeviceTypeBuiltInUltraWideCamera = 'AVCaptureDeviceTypeBuiltInUltraWideCamera'
AVCaptureDeviceTypeBuiltInDualCamera = 'AVCaptureDeviceTypeBuiltInDualCamera'
AVCaptureDeviceTypeBuiltInDualWideCamera = 'AVCaptureDeviceTypeBuiltInDualWideCamera'
AVCaptureDeviceTypeBuiltInTripleCamera = 'AVCaptureDeviceTypeBuiltInTripleCamera'
AVCaptureDeviceTypeBuiltInTrueDepthCamera = 'AVCaptureDeviceTypeBuiltInTrueDepthCamera'
AVCaptureDeviceTypeBuiltInDuoCamera = 'AVCaptureDeviceTypeBuiltInDuoCamera'
AVCaptureDeviceTypeBuiltInLiDARDepthCamera = 'AVCaptureDeviceTypeBuiltInLiDARDepthCamera'

# https://docs.microsoft.com/ja-jp/dotnet/api/avfoundation.avcapturedevicetype?view=xamarin-ios-sdk-12
BuiltInMicrophone  =  0
BuiltInTelephotoCamera  =  2
#BuiltInDuoCamera  =  3
BuiltInDualCamera  =  4
BuiltInTrueDepthCamera  =  5

# AVCaptureDevicePosition
AVCaptureDevicePositionBack = 1  # AVCaptureDevicePositionUnspecified = 0?
AVCaptureDevicePositionFront = 2

# 下記多分間違ってる
AVMediaTypeVideo = 0
AVMediaTypeAudio = 1
AVMediaTypeText = 2
AVMediaTypeClosedCaption = 3
AVMediaTypeSubtitle = 4
AVMediaTypeTimecode = 5
AVMediaTypeMetadata = 6
AVMediaTypeMuxed = 7


kCVPixelFormatType_DisparityFloat16 = 1751411059
kCVPixelFormatType_DisparityFloat32 = 1717856627
kCVPixelFormatType_DepthFloat16 = 1751410032
kCVPixelFormatType_DepthFloat32 = 1717855600

main_view = None
captureSession = None
delegate = None
videoDataOutput = None
depthDataOutput = None

processed_frames = 0
images = []

def processPixelBuffer(pixelData):
    global images
    base_address  = CVPixelBufferGetBaseAddressOfPlane(pixelData, 0)
    bytes_per_row = CVPixelBufferGetBytesPerRowOfPlane(pixelData, 0)
    width = CVPixelBufferGetWidthOfPlane(pixelData, 0)
    height = CVPixelBufferGetHeightOfPlane(pixelData, 0)
    image = np.ctypeslib.as_array(
        ctypes.cast( base_address, ctypes.POINTER(ctypes.c_ubyte) ),
        shape=((height, width))  )
    images.append(copy.copy(image))

def dataOutputSynchronizer_didOutputSynchronizedDataCollection_(
              _self, _cmd, _synchronizer_, _synchronizedDataCollection_):
    global processed_frames, videoDataOutput, depthDataOutput, images
    synchronizedDataCollection_ = ObjCInstance(_synchronizedDataCollection_)
    
    syncedVideoData = synchronizedDataCollection_.synchronizedDataForCaptureOutput_(videoDataOutput)
    syncedDepthData = synchronizedDataCollection_.synchronizedDataForCaptureOutput_(depthDataOutput)

    if syncedVideoData and syncedDepthData:
        sampleBuffer = ObjCInstance(syncedVideoData).sampleBuffer()
        sampleBuffer_ = ObjCInstance(sampleBuffer)
        # サンプルバッファを読み込む
        pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer_)
        # サンプルバッファをロック
        CVPixelBufferLockBaseAddress(pixelBuffer, 0)
        video_bytes_per_row = CVPixelBufferGetBytesPerRowOfPlane(pixelBuffer,0)
        video_width = CVPixelBufferGetWidthOfPlane(pixelBuffer,0)
        video_height = CVPixelBufferGetHeightOfPlane(pixelBuffer,0)
        video_base_address = CVPixelBufferGetBaseAddressOfPlane(pixelBuffer,0)
        # サンプルバッファをアンロック
        CVPixelBufferUnlockBaseAddress(pixelBuffer, 0)
        
        #if syncedDepthData:
        cameraCalibrationData = syncedDepthData.depthData().cameraCalibrationData()
        depthDataMap = ObjCInstance(syncedDepthData.depthData().depthDataMap())
        CVPixelBufferLockBaseAddress(depthDataMap, 0)
        depth_bytes_per_row = CVPixelBufferGetBytesPerRowOfPlane(depthDataMap,0)
        depth_width = CVPixelBufferGetWidthOfPlane(depthDataMap,0)
        depth_height = CVPixelBufferGetHeightOfPlane(depthDataMap,0)
        depth_base_address = CVPixelBufferGetBaseAddressOfPlane(depthDataMap,0)
        CVPixelBufferUnlockBaseAddress(depthDataMap, 0)
        
        video = np.ctypeslib.as_array(
            ctypes.cast( video_base_address,
                         ctypes.POINTER(ctypes.c_uint) ),
            shape=( (video_height, video_width) )
        )
        depth = np.ctypeslib.as_array(
            ctypes.cast( depth_base_address,
                         ctypes.POINTER(ctypes.c_uint16) ),
            shape=( (depth_height, depth_width) )
        )
        images.append({'depth':copy.copy(depth), 'video':copy.copy(video)})
    
    processed_frames = processed_frames + 1

# delegate を登録する
myAVCaptureDataOutputSynchronizerDelegate = create_objc_class(
        'myAVCaptureDataOutputSynchronizerDelegate',
        methods=[dataOutputSynchronizer_didOutputSynchronizedDataCollection_],
        protocols=['AVCaptureDataOutputSynchronizerDelegate'])

def button_tapped(sender):
    global debugflg
    debugflg = 1
    
@on_main_thread
def video_shooting_setup(ui_view, captureDeviceType, sessionPreset = 'AVCaptureSessionPreset640x480'):
    global captureSession, delegate,videoDataOutput, depthDataOutput
    # ui_viewを追加
    #main_view = get_view_controllers()[1].view()
    main_view = get_mainview()
    add_uiview_to_mainview(ui_view,main_view)
    
    # デバイスを開く
    # https://forum.omz-software.com/user/pavlinb/posts
    captureDeviceDiscoverySession = AVCaptureDeviceDiscoverySession.discoverySessionWithDeviceTypes_mediaType_position_(
        ['AVCaptureDeviceTypeBuiltInLiDARDepthCamera' ],
        'vide', # AVMediaTypeVideo
        1 ) # AVCaptureDevicePositionBack
    captureDevices = captureDeviceDiscoverySession.devices()
    device = captureDevices[0] # 該当する最初のデバイスを選択
    
    # キャプチャデバイスから”input”を作る
    deviceInput = AVCaptureDeviceInput.deviceInputWithDevice_error_(device, None)
    # inputをsessionに追加
    captureSession = AVCaptureSession.alloc().init()
    captureSession.addInput_(deviceInput)
    
    # 画像をキャプチャするdelegateを作成
    myAVCaptureDataOutputSynchronizerDelegate_ = myAVCaptureDataOutputSynchronizerDelegate.new()
    
    # que
    queue = ObjCInstance( dispatch_get_current_queue() )
    # AVCaptureVideoDataOutputとAVCaptureDepthDataOutput を作成
    videoDataOutput = AVCaptureVideoDataOutput.alloc().init()
    depthDataOutput = AVCaptureDepthDataOutput.alloc().init()

    # session に output を接続
    captureSession.addOutput_(videoDataOutput)
    captureSession.addOutput_(depthDataOutput)
    
    outputVideoSync = AVCaptureDataOutputSynchronizer.alloc()#.init()
    outputVideoSync.initWithDataOutputs_([videoDataOutput,depthDataOutput]) # ,

    captureSession.sessionPreset = 'AVCaptureSessionPreset640x480'
    # キャプチャするdelegateとqueue設定
    outputVideoSync.setDelegate_queue_( myAVCaptureDataOutputSynchronizerDelegate_, queue )
    
    # キャプチャデバイスからのビデオを表示するためのAVCaptureVideoPreviewLayer
    prev_layer = AVCaptureVideoPreviewLayer.layerWithSession_(captureSession)
    prev_layer.setVideoGravity_('AVLayerVideoGravityResizeAspectFill')
    prev_layer.frame = ui_view.bounds()
    # AVCaptureVideoPreviewLayer インスタンスを、現在のViewに追加
    ui_view.layer().addSublayer_(prev_layer)

@on_main_thread
def video_shooting_start():
    global captureSession
    captureSession.startRunning()

@on_main_thread
def video_shooting_close(ui_view):
    global captureSession, delegate, videoDataOutput, depthDataOutput, processed_frames
    captureSession.stopRunning()
    captureSession.release()
    videoDataOutput.release()
    depthDataOutput.release()
    # プレビューレイヤーを消す（Noneにはしない）
    remove_uiview_fromsuper(ui_view)
    print( "processed_frames:{}".format(processed_frames))

if __name__ == '__main__':
    main()



