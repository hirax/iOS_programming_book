# coding: utf-8
# Copyright (c) 2018 Jun Hirabayashi (jun@hirax.net)
# Released under the MIT license
# https://opensource.org/licenses/mit-license.php

from classes.header import *
import rubicon_objc
import ctypes

# 気圧計が利用可能か確認する
if not CMAltimeter.isRelativeAltitudeAvailable():
    print("Altitude is NOT available.")
    raise
else:
    print("Altitude sensor is Available.")

altitudeData = []

# handler for getting CMAttitude
def handler(_data:ctypes.c_void_p, _error:ctypes.c_void_p) ->None:
        global altitudeData
        altitudeData.append(
            {  # デバイス起動からの秒: NSTimeInterval
               'timestamp':rubicon_objc.api.py_from_ns( rubicon_objc.api.ObjCInstance(_data).timestamp ),
               # 相対標高(m): NSNumber
               'relativeAltitude':rubicon_objc.api.py_from_ns( rubicon_objc.api.ObjCInstance(_data).relativeAltitude ),
               # 気圧(kパスカル): NSNumber
               'pressure':rubicon_objc.api.py_from_ns( rubicon_objc.api.ObjCInstance(_data).pressure )
            })
handler_block = rubicon_objc.api.Block( handler )

CMAltimeter_ = CMAltimeter.new()

def startRelativeAltitudeUpdates():
    CMAltimeter_.startRelativeAltitudeUpdatesToQueue_withHandler_(
        NSOperationQueue.mainQueue, handler_block)

def stopRelativeAltitudeUpdates():
    CMAltimeter_.stopRelativeAltitudeUpdates()

if __name__ == '__main__':

    import time
    altitudeData.clear()
    startRelativeAltitudeUpdates()
    time.sleep(5)
    stopRelativeAltitudeUpdates()
    print(altitudeData)
