# https://forum.omz-software.com/topic/3896/objc_tools-library/4

from objc_util import ObjCClass, ObjCBlock, c_void_p, ObjCInstance,ns

# システム算出の歩数を得るためのCMPedometer
CMPedometer = ObjCClass('CMPedometer')
CMPedometer_ = CMPedometer.alloc().init()
NSDate = ObjCClass('NSDate')

# 歩数情報を格納するリストを作っておく
pedometerData = []

# 歩数を得るためのハンドラーを書く
def getData(_cmd, _pedometerData, error):
    global pedometerData
    pedometer = ObjCInstance(_pedometerData)
    if not error == None:
        err = ObjCInstance(error)
        print('error:'+str(err))
    else:
        pedometerData.append({
        # NSNumberは所望の形式で値が出せる
        # 単位は歩数
        'numberOfSteps':pedometer.numberOfSteps().unsignedIntegerValue(),
        'distance':pedometer.distance().floatValue()  # 単位はm
        })
# ハンドラーを登録する
pedometer_block = ObjCBlock(
        getData,
        restype=None,
        argtypes=[c_void_p, c_void_p, c_void_p])

def queryPedometerDataFromDatetoDate(fromDate,toDate):
    if CMPedometer.isStepCountingAvailable():
        # 歩数を調べる
        CMPedometer_.queryPedometerDataFromDate_toDate_withHandler_(
            ns(fromDate),
            ns(toDate),
            pedometer_block)
    else:
        print('Unavailable')

