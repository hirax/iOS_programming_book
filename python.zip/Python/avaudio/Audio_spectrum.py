# https://gist.github.com/jsbain/33d90edb232d8e825a8461c7aba23b95

from objc_util import *
import ctypes
import io

import time
AVAudioEngine=ObjCClass('AVAudioEngine')
AVAudioSession=ObjCClass('AVAudioSession')

def setup():
	error=ctypes.c_void_p(0)
	session=AVAudioSession.sharedInstance()
	category=session.setCategory('AVAudioSessionCategoryPlayAndRecord',error=ctypes.pointer(error))
	if error:
		raise Exception('error setting up category')
	session.setActive(True, error=ctypes.pointer(error))
	if error:
		raise Exception('error setting up session active')
	engine=AVAudioEngine.new()
	return engine


'''setup a tap block'''
buf=[] #for debugging
bIO=io.BytesIO()
lastt=0

def processBuffer(self,buffer,when, cmd):
	try:
		global lastt
		global timing
		#global buf
		buf=ObjCInstance(buffer )
	except:
		engine.pause()
		raise

process_block=ObjCBlock(processBuffer,restype=None,argtypes=[c_void_p,c_void_p,c_void_p,c_void_p])

'''set up audio engine, and install tap, and start'''
engine=setup()
engine.connect_to_format_(engine.inputNode(),
									engine.outputNode(),
									engine.inputNode().inputFormatForBus_(0))

engine.inputNode().installTapOnBus(0,
					bufferSize=64*256,
					format=None,
					block=process_block)

engine.prepare()

engine.startAndReturnError_(None)

time.sleep(3)

engine.stop()
