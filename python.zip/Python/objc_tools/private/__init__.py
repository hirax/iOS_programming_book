__doc__ = '''This is a submodule which uses mainly private APIs.
             Things will break and may never be fixed.
             You have been warned'''
