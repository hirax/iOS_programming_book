from avfoundation.av_speech_synthesizer import *

speech(str="Hello world!")

speech(str="こんにちはPython.",rate=0.5, volume = 1.0,
    pitchMultiplier = 1.0, preUtteranceDelay = 0.2,
    voice='com.apple.ttsbundle.siri_Hattori_ja-JP_compact')

