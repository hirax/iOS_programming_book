# coding: utf-8
# Copyright (c) 2018 Jun Hirabayashi (jun@hirax.net)
# Released under the MIT license
# https://opensource.org/licenses/mit-license.php

# from iOS04

from ctypes import *
from rubicon.objc import ObjCClass,ObjCInstance, Block
from rubicon.objc.runtime import *
from rubicon.objc.types import *

class CMAcceleration(Structure):
    _fields_ = [ ('x', c_double),   # m/s^2.
                 ('y', c_double),   # m/s^2.
                 ('z', c_double) ]  # m/s^2.
    
# クラスへのリファレンスを作る
CMMotionManager= ObjCClass('CMMotionManager')
NSOperationQueue = ObjCClass('NSOperationQueue')
CMAccelerometerData = ObjCClass('CMAccelerometerData')

# クラスのインスタンスを作成
CMMotionManager_ = CMMotionManager.alloc().init()
if not CMMotionManager_.isAccelerometerAvailable():
    print("accelerometer in NOT Available.")
    raise
else:
    print("accelerometer is Available.")

import time

# 便利のために変数などを用意しておく
CMMotionManager_.accelerometerUpdateInterval = 0.1 # 単位は秒
accelerometerUpdateInterval = CMMotionManager_.accelerometerUpdateInterval
accelerometerData = []

# センサ値取得時のハンドラー関数を作る
def _handler( _data:c_void_p, _error:c_void_p ) -> None:
    global accelerometerData
    obj = ObjCInstance(_data)
    acc = send_message(obj,'acceleration',
                       restype=CMAcceleration,
                       argtypes=[])
    ts = send_message( obj,'timestamp', # NSTimeInterval(s) from booting
                       restype=c_double,
                       argtypes=[])
    accelerometerData.append( {'x':acc.x,'y':acc.y,'z':acc.z,'at':ts} )
    #acceleration = obj.acceleration(argtypes=[],
    #                                restype=CMAcceleration)
    #val = obj.__str__().split()
handler_block = Block( _handler )

def startAccelerometerUpdates():
    CMMotionManager_.startAccelerometerUpdatesToQueue_withHandler_(
        NSOperationQueue.mainQueue, handler_block )

def stopAccelerometerUpdates():
        CMMotionManager_.stopAccelerometerUpdates()

if __name__ == '__main__':
    # 加速度センサ値を格納する変数を初期化しておく
    accelerometerData.clear()
    # 計測を開始する
    startAccelerometerUpdates()
    # * 秒間計測を続ける
    time.sleep(3) # 単位は秒
    # 計測を終了させる
    stopAccelerometerUpdates()
    # 結果を表示
    print( accelerometerData )
