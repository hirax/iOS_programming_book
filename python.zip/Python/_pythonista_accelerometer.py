# 加速度センサ機能を使うためのモジュールを読み込む
from coremotion.accelerometer import *

# 加速度センサ値を格納する変数を初期化しておく
accelerometerData.clear()
# 加速度センサ（accelerometer）の更新時間を設定
CMMotionManager_.accelerometerUpdateInterval = 0.1 # 単位は秒
# 計測を開始する
CMMotionManager_.startAccelerometerUpdatesToQueue_withHandler_(
    NSOperationQueue.mainQueue, handler_block )
# * 秒間計測を続ける
time.sleep(3) # 単位は秒
# 計測を終了させる
CMMotionManager_.stopAccelerometerUpdates()

# 取得した計測値を図示する
import matplotlib.pyplot as plt

x = []; y = []; z = []; t = []
for a in accelerometerData:
    x.append(a['x']); y.append(a['y'])
    z.append(a['z']); t.append(a['at'])

plt.scatter(t,x,c="r"); plt.plot(t,x,c="r")
plt.scatter(t,y,c="g"); plt.plot(t,y,c="g")
plt.scatter(t,z,c="b"); plt.plot(t,z,c="b")
plt.xlabel('Time (s)')
plt.ylabel('Acclerometer (m/s^2)')
#plt.show()

print( accelerometerData )


